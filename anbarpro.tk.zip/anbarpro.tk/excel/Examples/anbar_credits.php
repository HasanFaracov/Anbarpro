<?php
session_start();
/**
 * PHPExcel
 *
 * Copyright (c) 2006 - 2015 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2015 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
require_once dirname(__FILE__) . '/../Classes/PHPExcel.php';


// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Maarten Balliauw")
							 ->setLastModifiedBy("Maarten Balliauw")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Test result file");



$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getStyle('B2:P2')->getFont()->setBold(true);

// Add some data
$objPHPExcel->setActiveSheetIndex(0) 
            ->setCellValue('B2', '#')
            ->setCellValue('C2', 'Müştəri')
            ->setCellValue('D2', 'Məhsul')
            ->setCellValue('E2', 'Miqdar')
            ->setCellValue('F2', 'Faiz')
            ->setCellValue('G2', 'Kredit müddəti')
            ->setCellValue('H2', 'İlkin ödəniş')
            ->setCellValue('I2', 'Qiymət')
            ->setCellValue('J2', 'Borc')
            ->setCellValue('K2', 'Aylıq ödəniş')
            ->setCellValue('L2', 'Qalan müddət')
            ->setCellValue('M2', 'Ödənilən')
            ->setCellValue('N2', 'Depozit')
            ->setCellValue('O2', 'Ödənilən')
            ->setCellValue('P2', 'Tarix');




$con = mysqli_connect('localhost','u1491059_anbarpro','Eokad23247','u1491059_anbarpro');

$sec = mysqli_query($con,"SELECT 
    credits.id,
    credits.client_id,
    credits.product_id,
    credits.muddet,
    credits.faiz,
    credits.ilk,
    credits.tesdiq,
    credits.odenilib,
    credits.depozit,
    products.ad AS mehsul,
    clients.ad AS client,
    clients.soyad,
    products.alis,
    products.satis,
    products.miqdar AS mehsul_miqdar,
    credits.miqdar AS credit_miqdar,
    credits.tarix,
    brands.ad AS brend
    FROM credits, products, brands, clients, users 
    WHERE (credits.product_id=products.id) 
    AND (credits.client_id=clients.id) AND (products.brand_id=brands.id)
    AND (credits.user_id = users.id) AND (credits.user_id = ".$_SESSION['user_id'].")");
$i = 2;
$n = 0;

while($info = mysqli_fetch_array($sec))
{
    $i++;
    $n++;
    $bugun= date("Y-m-d H:i:s");
    $kredit_tarixi = $info['tarix'];
    $kredit_bitme_tarixi =  date('Y-m-d', strtotime("+".$info['muddet']." months", strtotime($kredit_tarixi)));
    $kredit_qalan_san = strtotime($kredit_bitme_tarixi);
    $bugun_san = strtotime($bugun);
    $kredit_qalan_gun = round(($kredit_qalan_san-$bugun_san)/(60*60*24)) ;
    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('B'.$i, $n)
            ->setCellValue('C'.$i, $info['client'].' '.$info['soyad'])
            ->setCellValue('D'.$i, $info['mehsul'].' ( '.$info['brend'].' )')
            ->setCellValue('E'.$i, $info['credit_miqdar'])
            ->setCellValue('F'.$i, $info['faiz'].'%')
            ->setCellValue('G'.$i, $info['muddet'].' ay')
            ->setCellValue('H'.$i, $info['ilk'])
            ->setCellValue('I'.$i, round(($info['satis']*$info['credit_miqdar'])*(1+$info['faiz']/100), 3))
            ->setCellValue('J'.$i, (round((($info['satis']*$info['credit_miqdar'])*(1+$info['faiz']/100))-$info['ilk'], 3)-($info['odenilib']*round(((($info['satis']*$info['credit_miqdar'])*(1+$info['faiz']/100))-$info['ilk'])/$info['muddet'], 3))))
            ->setCellValue('K'.$i, round(((($info['satis']*$info['credit_miqdar'])*(1+$info['faiz']/100))-$info['ilk'])/$info['muddet'], 3))
            ->setCellValue('L'.$i, $kredit_qalan_gun.' gün')
            ->setCellValue('M'.$i, $info['odenilib'].'/'.$info['muddet'].' ay')
            ->setCellValue('N'.$i, $info['depozit'])
            ->setCellValue('O'.$i, $info['odenilib']*round(((($info['satis']*$info['credit_miqdar'])*(1+$info['faiz']/100))-$info['ilk'])/$info['muddet'], 3))
            ->setCellValue('P'.$i, $info['tarix']);
}

// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Simple');


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="credits_'.date('Y_m_d_H_i_s').'.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
